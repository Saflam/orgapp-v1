<?php

namespace Modules\Member\Http\Controllers\Api;

use Illuminate\Http\JsonResponse;
use Modules\Member\Http\Requests\StoreMembershipApplicationRequest;
use Modules\Member\Http\Resources\MembershipApplicationResource;
use Modules\Member\Services\MemberRegistrationService;

class MembershipApplicationController
{
    public function __construct(
        private MemberRegistrationService $registrationService,
    ) {
    }

    public function store(
        StoreMembershipApplicationRequest $request,
    ): JsonResponse {
        $validated = $request->validated();

        $member = $this->registrationService->register(
            memberData: [
                'organization_id' => $request->route('organization')->id,
                'user_id' => $validated['user_id'],
                'membership_number' => $validated['membership_number'],
                'date_of_birth' => $validated['date_of_birth'] ?? null,
                'unit_id' => $validated['unit_id'] ?? null,
                'joined_at' => $validated['joined_at'] ?? null,
                'metadata' => $validated['metadata'] ?? [],
            ],
            membershipTypeId: $validated['membership_type_id'],
            startsAt: $validated['starts_at'],
            extensionData: $validated['extension_data'] ?? [],
            addressData: $validated['address'],
        );

        return response()->json(
            new MembershipApplicationResource($member),
            201
        );
    }
}