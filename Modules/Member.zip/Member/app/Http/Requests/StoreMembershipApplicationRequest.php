<?php

namespace Modules\Member\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Modules\Core\Models\Organization;
use Modules\Core\Services\OrganizationIdentificationService;
use Modules\Member\Services\MembershipApplicationExtensionRegistry;

class StoreMembershipApplicationRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        $organization = $this->route('organization');

        if (! $organization instanceof Organization) {
            return $this->baseRules();
        }

        $rules = $this->baseRules();

        $extensionRules = app(
            MembershipApplicationExtensionRegistry::class
        )->rules($organization);

        foreach ($extensionRules as $module => $moduleRules) {
            foreach ($moduleRules as $field => $fieldRules) {
                $rules[
                    "extension_data.{$module}.{$field}"
                ] = $fieldRules;
            }
        }

        $identificationRules = $this->identificationRules(
            $organization
        );

        foreach ($identificationRules as $field => $fieldRules) {
            $rules[$field] = $fieldRules;
        }

        return $rules;
    }

    /**
     * Build organization-specific identification validation rules.
     *
     * Only enabled identification types are accepted.
     * Required identification types must be submitted.
     *
     * @return array<string, array<int, mixed>>
     */
    private function identificationRules(
        Organization $organization,
    ): array {
        $configurations = app(
            OrganizationIdentificationService::class
        )->enabled($organization);

        $codes = $configurations
            ->map(
                fn ($configuration) =>
                    $configuration->identificationType->code
            )
            ->values()
            ->all();

        $rules = [
            'identifications' => [
                'sometimes',
                'array',
                function (
                    string $attribute,
                    mixed $value,
                    \Closure $fail,
                ) use ($codes): void {
                    if (! is_array($value)) {
                        return;
                    }

                    foreach (array_keys($value) as $code) {
                        if (! in_array($code, $codes, true)) {
                            $fail(
                                "The identification type [{$code}] "
                                . 'is not enabled for this organization.'
                            );
                        }
                    }
                },
            ],
        ];

        foreach ($configurations as $configuration) {
            $code = $configuration->identificationType->code;

            $rules[
                "identifications.{$code}"
            ] = [
                $configuration->is_required
                    ? 'required'
                    : 'nullable',
                'string',
                'max:255',
            ];
        }

        return $rules;
    }

    /**
     * @return array<string, array<int, mixed>>
     */
    private function baseRules(): array
    {
        return [
            'user_id' => [
                'required',
                'integer',
                'exists:users,id',
            ],

            'membership_type_id' => [
                'required',
                'integer',
                'exists:membership_types,id',
            ],

            'starts_at' => [
                'required',
                'date',
            ],

            'membership_number' => [
                'required',
                'string',
                'max:255',
            ],

            'first_name' => [
                'required',
                'string',
                'max:255',
            ],

            'middle_name' => [
                'nullable',
                'string',
                'max:255',
            ],

            'last_name' => [
                'nullable',
                'string',
                'max:255',
            ],

            'date_of_birth' => [
                'nullable',
                'date',
            ],

            'gender' => [
                'nullable',
                'string',
                'max:50',
            ],

            'whatsapp' => [
                'nullable',
                'string',
                'max:50',
            ],

            'whatsapp_calling_code' => [
                'nullable',
                'string',
                'max:10',
            ],

            'home_contact' => [
                'nullable',
                'string',
                'max:50',
            ],

            'profession' => [
                'nullable',
                'string',
                'max:255',
            ],

            'company' => [
                'nullable',
                'string',
                'max:255',
            ],

            'unit_id' => [
                'nullable',
                'integer',
                'exists:units,id',
            ],

            'joined_at' => [
                'nullable',
                'date',
            ],

            'metadata' => [
                'nullable',
                'array',
            ],

            'address' => [
                'required',
                'array',
            ],

            'address.address_type' => [
                'required',
                'string',
                'max:50',
            ],

            'address.address_line_1' => [
                'required',
                'string',
                'max:255',
            ],

            'address.address_line_2' => [
                'nullable',
                'string',
                'max:255',
            ],

            'address.locality' => [
                'nullable',
                'string',
                'max:255',
            ],

            'address.city' => [
                'nullable',
                'string',
                'max:255',
            ],

            'address.state' => [
                'nullable',
                'string',
                'max:255',
            ],

            'address.postal_code' => [
                'nullable',
                'string',
                'max:50',
            ],

            'address.country' => [
                'nullable',
                'string',
                'max:255',
            ],

            'address.is_primary' => [
                'sometimes',
                'boolean',
            ],

            'address.metadata' => [
                'nullable',
                'array',
            ],

            'extension_data' => [
                'sometimes',
                'array',
            ],
        ];
    }
}