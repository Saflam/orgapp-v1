<?php

namespace Modules\Member\Services;

use App\Models\UserAddress;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use Modules\Core\Models\Organization;
use Modules\Member\Enums\MembershipStatus;
use Modules\Member\Models\Member;
use Modules\Member\Models\Membership;
use Modules\Member\Models\MembershipType;

class MemberRegistrationService
{
    public function __construct(
        private MemberService $memberService,
        private MembershipApplicationExtensionRegistry $extensionRegistry,
        private UserIdentificationService $userIdentificationService,
    ) {
    }

    /**
     * Register a member and create their initial membership.
     *
     * @param array<string, mixed> $memberData
     * @param array<string, mixed> $addressData
     * @param array<string, array<string, mixed>> $extensionData
     * @param array<string, array<string, mixed>> $identificationData
     */
    public function register(
        array $memberData,
        int $membershipTypeId,
        string $startsAt,
        array $extensionData = [],
        array $addressData = [],
        array $identificationData = [],
    ): Member {
        return DB::transaction(function () use (
            $memberData,
            $membershipTypeId,
            $startsAt,
            $extensionData,
            $addressData,
            $identificationData,
        ) {
            $membershipType = MembershipType::query()->find(
                $membershipTypeId
            );

            if (! $membershipType) {
                throw ValidationException::withMessages([
                    'membership_type_id' =>
                        'The selected membership type does not exist.',
                ]);
            }

            if (
                $membershipType->organization_id
                !== $memberData['organization_id']
            ) {
                throw ValidationException::withMessages([
                    'membership_type_id' =>
                        'The selected membership type does not belong to the selected organization.',
                ]);
            }

            $organization = Organization::query()->findOrFail(
                $memberData['organization_id']
            );

            $member = $this->memberService->create($memberData);

            Membership::create([
                'member_id' => $member->id,
                'membership_type_id' => $membershipType->id,
                'starts_at' => $startsAt,
                'ends_at' => null,
                'status' => MembershipStatus::IN_REVIEW,
                'metadata' => [],
            ]);

            if ($addressData !== []) {
                UserAddress::create([
                    'user_id' => $member->user_id,
                    ...$addressData,
                ]);
            }

            foreach ($identificationData as $identification) {
                $identificationType = $identification['identification_type'];

                $this->userIdentificationService->save(
                    user: $member->user,
                    identificationType: $identificationType,
                    data: [
                        'identification_number' =>
                            $identification['identification_number'],
                        'metadata' =>
                            $identification['metadata'] ?? null,
                    ],
                );
            }

            $this->extensionRegistry->persist(
                organization: $organization,
                member: $member,
                extensionData: $extensionData,
            );

            return $member->load([
                'user.details',
                'memberships',
            ]);
        });
    }
}