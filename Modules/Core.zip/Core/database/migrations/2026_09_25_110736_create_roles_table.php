<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('roles', function (Blueprint $table) {
            $table->id();

            $table->foreignId('organization_id')
                ->nullable()
                ->constrained('organizations')
                ->nullOnDelete();

            $table->string('name');

            $table->string('code', 100);

            $table->text('description')->nullable();

            $table->boolean('is_system')
                ->default(false);

            $table->timestamps();

            $table->unique(
                ['organization_id', 'code'],
                'roles_org_code_unique'
            );

            $table->index('is_system');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('roles');
    }
};