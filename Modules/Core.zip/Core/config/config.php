<?php

return [
    'name' => 'Core',
];
